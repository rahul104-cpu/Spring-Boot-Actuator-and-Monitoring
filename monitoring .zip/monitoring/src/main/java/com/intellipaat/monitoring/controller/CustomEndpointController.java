// Health and Info Endpoints are automatically provided by Actuator
package com.intellipaat.monitoring.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomEndpointController {

    @GetMapping("/api/xyz")
    public ResponseEntity<String> xyzEndpoint() {
        // Your logic here
        return ResponseEntity.ok("XYZ Endpoint Accessed");
    }
}
