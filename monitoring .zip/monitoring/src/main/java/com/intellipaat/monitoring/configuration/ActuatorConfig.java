package com.intellipaat.monitoring.configuration;

import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

@Configuration
public class ActuatorConfig {

    @Bean
    public MeterRegistryCustomizer<MeterRegistry> commonTags() {
        return registry -> registry.config().commonTags("application", "XYZMonitoringSystem");
    }

    @Autowired
    private MeterRegistry registry;

    @PostConstruct
    public void configureMetrics() {
        registry.counter("custom.endpoint.requests", "endpoint", "/api/xyz");
    }
}
